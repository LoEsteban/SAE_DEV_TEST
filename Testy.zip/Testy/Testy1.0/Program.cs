﻿
using var game = new Testy1._0.Game1();
game.Run();
